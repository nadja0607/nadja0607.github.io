
var bet = 0;
function roll() {

    let user = parseInt(document.getElementById("bet").value);
    // rolling each die randomelly 
    var die1 = Math.floor(Math.random() * 6) + 1;
    var die2 = Math.floor(Math.random() * 6) + 1;
    // sum of rolling 2 dice
    var total = die1 + die2;
    console.log('die1 -- ', die1)
    console.log('die2 -- ', die2)
    console.log(user)
    //display and proceed only whn user bet input is valid
    if (user>4){
        // changing image src loaded in the document using the images[]
        document.images[3].src="./images/dice_" + die1+ ".gif";
        document.images[4].src="./images/dice_" + die2 + ".gif";
        document.getElementById('output').innerHTML = "Total is: " + total;
        if (total == 7 || total==11) {
            document.getElementById('message').innerHTML = "Congratulations!! You WON!!"
            bet = bet + user
            console.log(bet)
        }
        else if (total == 2 || total==3 || total==12) {
            document.getElementById('message').innerHTML = "Better Luck Next Time :( You Lost"
            bet = 0
            console.log(bet)
        }
        else{
            document.getElementById('message').innerHTML = "Keep Going ....."
            bet = bet + user
            console.log(bet)
        }
    }
 }